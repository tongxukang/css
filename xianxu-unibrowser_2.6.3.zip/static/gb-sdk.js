

let gb ={
	
	ui(view){
		
	}
}

export default gb