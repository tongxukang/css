const mimeTypes = "text/plain|application/msword|application/vnd.openxmlformats-officedocument.wordprocessingml.document|application/vnd.ms-excel application/x-excel|application/vnd.openxmlformats-officedocument.spreadsheetml.sheet|application/vnd.ms-powerpoint|application/vnd.ms-powerpoint|application/vnd.openxmlformats-officedocument.presentationml.presentation|application/pdf";

const docType = ['doc','xls','ppt','pdf','docx','xlsx','pptx','js'];
// const filepath = ['常用应用','内部存储']
const filepath = ['常用应用']

export default {
	mimeTypes,
	docType,
	filepath					
}
